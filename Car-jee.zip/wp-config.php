<?php
/** Enable W3 Total Cache */
define('WP_CACHE', true); // Added by W3 Total Cache



/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'etiluxxh_carjee');

/** MySQL database username */
define('DB_USER', 'etiluxxh_carjee');

/** MySQL database password */
define('DB_PASSWORD', '9*33,d^$DQSQ');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ')0.N5<) pb@ZUAPFI$l#tK4<%&uV~+39f>cvjpq&FZ#5+]oL/vh;(Q23Ga8|<~+4');
define('SECURE_AUTH_KEY',  'y2mvX8v07h!y[f#YDu,n5Barp?VtJ.>j]JkL71j~d]7h,)1r@l#!5 &$rg{u2/`p');
define('LOGGED_IN_KEY',    'htNjvp0.]:{t2Ks9WM| s3jd7ovV&E SljW[W2;8YL^jbE{`D-jJ]/PcMTo?_TrB');
define('NONCE_KEY',        'Rd<|gOkUeo5}0KTg!U|c7VtFJ@2g+Y57<FP3YCXn!rH_Ae<TwST6b=@]l|zCTyaF');
define('AUTH_SALT',        'ASHlYcX<^H5sOrKGakvj#f%%%uV46`Z0jJN[UJ[%6`nL6_8(TAH}h)G&@~%g%?[,');
define('SECURE_AUTH_SALT', 'hta3@}Sa REJ6l~6^Z3eHVTkL:V$I#4w[gglqSu|]_*|=9BZRr}TzA~.U!^Lku|2');
define('LOGGED_IN_SALT',   '!3d-a.~A;ONl`%O8wu,Uxe}7Y)f3ujR(ekP|B`)zp#%nRORs`;=N2-O6brcS9!$<');
define('NONCE_SALT',       'ELlA!Zr<{WF[_TQ 6$L=K?BuwfizQL4[$|JCu7vm5+)VPt@f2:HObP,SfXaaMmr]');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
